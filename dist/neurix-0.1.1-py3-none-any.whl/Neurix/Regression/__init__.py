from .GDRidgeRegression import GDRidge
from .LinearRegression import LinearRegression
from .OLSRidgeRegression import OLSRidge
